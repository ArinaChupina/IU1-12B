package classes;

public class Vehicle {

}
